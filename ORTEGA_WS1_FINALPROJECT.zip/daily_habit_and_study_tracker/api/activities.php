<?php
require 'db.php';
$uid = need_login();
$method = $_SERVER['REQUEST_METHOD'];
const APP_TZ = 'Asia/Manila';
function today_str() {
    return (new DateTime('now', new DateTimeZone(APP_TZ)))->format('Y-m-d');
}
const COLS = "a.id, a.type, a.title, a.notes, a.activity_date AS date,
  TIME_FORMAT(a.activity_time,'%H:%i') AS time, TIME_FORMAT(a.start_time,'%H:%i') AS start,
  TIME_FORMAT(a.end_time,'%H:%i') AS end, a.priority AS pri, a.icon, a.color, a.is_done AS done,
  a.reminder_on AS rem, TIME_FORMAT(a.reminder_time,'%H:%i') AS remTime, c.name AS cat";
const CAT = "COALESCE((SELECT id FROM categories WHERE name = ? LIMIT 1), (SELECT id FROM categories WHERE name = 'Other' LIMIT 1))";

function fields($b) {
    $type = in_array($b['type'] ?? '', ['habit', 'study', 'task', 'meal'], true) ? $b['type'] : 'habit';
    $title = trim($b['title'] ?? '');
    if ($title === '' || mb_strlen($title) > 150) {
        out(['error' => 'A title is required (150 characters max).'], 400);
    }
    $date = $b['date'] ?? '';
    $dt = preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? DateTime::createFromFormat('!Y-m-d', $date) : false;
    if (!$dt || $dt->format('Y-m-d') !== $date) {
        out(['error' => 'Invalid date.'], 400);
    }
    
    if ($date < today_str()) {
        out(['error' => 'Past dates are locked. You can only add or edit activities for today or a future date.'], 400);
    }
    $t = function ($v) { return preg_match('/^\d{2}:\d{2}$/', $v ?? '') ? $v . ':00' : null; };
    $pri = in_array($b['pri'] ?? '', ['Low', 'Medium', 'High'], true) ? $b['pri'] : null;
    $color = preg_match('/^#[0-9A-Fa-f]{6}$/', $b['color'] ?? '') ? $b['color'] : null;
    return [
        $type, $title, mb_substr(trim($b['notes'] ?? ''), 0, 500), $date,
        $t($b['time'] ?? ''), $t($b['start'] ?? ''), $t($b['end'] ?? ''),
        $pri, mb_substr($b['icon'] ?? '', 0, 16), $color,
        empty($b['done']) ? 0 : 1, empty($b['rem']) ? 0 : 1, $t($b['remTime'] ?? ''),
        $b['cat'] ?? 'Other',
    ];
}
function owns($db, $id, $uid) {
    $s = $db->prepare('SELECT id FROM activities WHERE id = ? AND user_id = ?');
    $s->bind_param('ii', $id, $uid);
    $s->execute();
    return (bool) $s->get_result()->fetch_assoc();
}
if ($method === 'GET') {                                  
    $s = $db->prepare('SELECT ' . COLS . ' FROM activities a LEFT JOIN categories c ON c.id = a.category_id
                       WHERE a.user_id = ? ORDER BY a.activity_date, a.activity_time, a.id');
    $s->bind_param('i', $uid);
    $s->execute();
    $rows = $s->get_result()->fetch_all(MYSQLI_ASSOC);
    foreach ($rows as &$r) {
        $r['id'] = (int) $r['id'];
        $r['done'] = (bool) $r['done'];
        $r['rem'] = (bool) $r['rem'];
    }
    out($rows);
}
if ($method === 'POST') {                                 
    $p = array_merge([$uid], fields(body()));
    $s = $db->prepare('INSERT INTO activities (user_id, type, title, notes, activity_date, activity_time, start_time,
        end_time, priority, icon, color, is_done, reminder_on, reminder_time, category_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,' . CAT . ')');
    $s->bind_param('issssssssssiiss', ...$p);
    if (!$s->execute()) {
        out(['error' => 'Could not save the activity.'], 500);
    }
    out(['id' => $db->insert_id], 201);
}
$id = (int) ($_GET['id'] ?? 0);
if (!$id || !owns($db, $id, $uid)) {
    out(['error' => 'Activity not found.'], 404);
}
if ($method === 'PUT' || $method === 'DELETE') {
    $c = $db->prepare('SELECT activity_date FROM activities WHERE id = ? AND user_id = ?');
    $c->bind_param('ii', $id, $uid);
    $c->execute();
    $cur = $c->get_result()->fetch_assoc();
    if ($cur && $cur['activity_date'] < today_str()) {
        out(['error' => 'This activity is from a past date and is locked. It cannot be edited, marked done or deleted.'], 403);
    }
}
if ($method === 'PUT') {                                  
    $p = array_merge(fields(body()), [$id, $uid]);
    $s = $db->prepare('UPDATE activities SET type=?, title=?, notes=?, activity_date=?, activity_time=?, start_time=?,
        end_time=?, priority=?, icon=?, color=?, is_done=?, reminder_on=?, reminder_time=?, category_id=' . CAT . '
        WHERE id=? AND user_id=?');
    $s->bind_param('ssssssssssiissii', ...$p);
    if (!$s->execute()) {
        out(['error' => 'Could not update the activity.'], 500);
    }
    out(['ok' => true]);
}
if ($method === 'DELETE') {                                
    $s = $db->prepare('DELETE FROM activities WHERE id = ? AND user_id = ?');
    $s->bind_param('ii', $id, $uid);
    $s->execute();
    out(['ok' => true]);
}
out(['error' => 'Method not allowed.'], 405);