<?php
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

if (!empty($_SESSION['leave_at'])) {
    if (!isset($_GET['reload']) && time() - $_SESSION['leave_at'] > LEAVE_GRACE) {
        $_SESSION = [];
        session_destroy();
        session_start();
    } elseif (($_GET['action'] ?? '') !== 'leave') {
        unset($_SESSION['leave_at']);
    }
}
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', '0');
mysqli_report(MYSQLI_REPORT_OFF);

$db = new mysqli('localhost', 'root', '', 'daily_habit_and_study_tracker');
if ($db->connect_errno) {
    out(['error' => 'Database connection failed. Start MySQL in XAMPP and import database.sql in phpMyAdmin.'], 500);
}
$db->set_charset('utf8mb4');

function out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}
function body() {
    $j = json_decode(file_get_contents('php://input'), true);
    return is_array($j) ? $j : [];
}
function need_login() {
    if (empty($_SESSION['uid'])) {
        out(['error' => 'Please log in.'], 401);
    }
    return (int) $_SESSION['uid'];
}